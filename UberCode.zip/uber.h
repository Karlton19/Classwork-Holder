using namespace std;
class uber {
	public:
		//Constructor
		uber (string i_Driver, double i_Money_earned, bool i_Full_empty);
		//Accessors
		string getDriver();
		double getMoney_earned();
		bool getFull_empty();
		//Mutators
			//Leave blank
		//Facilitators
		void add_money(double fare);
		void pickUp();
		void dropOff();
	private:
		string Driver;
		double Money_earned;
		bool Full_empty;
};

