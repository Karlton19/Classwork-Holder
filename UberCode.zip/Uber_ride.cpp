#include <iostream>
#include "person.h"
#include "uber.h"
using namespace std;

//Method Definitions
person::person (string i_name, double i_Money_amount) {
	//private = copied
	name = i_name;
	Money_amount = i_Money_amount;
}

uber::uber (string i_Driver, double i_Money_earned, bool i_Full_empty) {
	Driver = i_Driver;
	Money_earned = i_Money_earned;
	Full_empty = i_Full_empty;
}

//Accessor Definitions
string person::getName() {
	return name;
}

double person::getMoney_amount() {
	return Money_amount;
}

double person::ride(){
	cout << "How much does the ride cost?\n";
	double cost;
	cin >> cost;
	Money_amount = Money_amount - cost;
	return cost;
}





string uber::getDriver() {
	return Driver;
}

double uber::getMoney_earned() {
	return Money_earned;
}

bool uber::getFull_empty() {
	return Full_empty;
}

void uber::add_money(double fare) {
	Money_earned = Money_earned + fare;
}


//MAIN
int main(){







	person A("A", 20);
	A.ride();



	person B("B", 35);
	B.ride();


	person C("C", 10);
	C.ride();


	person D("D", 14);
	D.ride();


	person E("E", 17);
	E.ride();



/*
	uber FirstClass("First Class", 0, 0);
	cout << FirstClass.getMoney_earned() << "\n";

	
	FirstClass.add_money(7);
	cout << FirstClass.getMoney_earned() << "\n";

*/

	return 0;
}
