#include <iostream>
#include "Fraction.h"
using namespace std;

//Method Definitions
fraction::fraction(int init_numerator, int init_denominator, int init_reciprocal, int init_multiplier){
	numerator = init_numerator;
	denominator = init_denominator;
	reciprocal = init_reciprocal;
	multiplier = init_multiplier;

}


int fraction::getNumerator() {
	return numerator;
}


int fraction::getDenominator(){
	return denominator;
}

int fraction::getReciprocal(){
	return reciprocal;
}


int fraction::getMultiplier(int num_alt, int recip_alt){
	return multiplier;
}



int main(){

	return 0;
}
