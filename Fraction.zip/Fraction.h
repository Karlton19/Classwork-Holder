using namespace std;
class fraction {
	public:
		//Constructor
		fraction (int init_numerator, int init_denominator, int init_reciprocal, int init_multiplier);
		//Accessors
		int getNumerator();
		int getDenominator();

		int getReciprocal();
		int getMultiplier(int num_alt, int recip_alt);
		//No Mutators Allowed
	private:
		int numerator;
		int denominator;
		int reciprocal;
		int multiplier;

};
